﻿
using var game = new final_projectM.Game1();
game.Run();
